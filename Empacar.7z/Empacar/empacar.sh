#!/bin/bash
check=$(ls | grep -c pack-list)
if [ $check = 0 ]
then
cat >> pack-list << EOF
$HOME/Documentos
/home/$USER/Imágenes
##	Podes poner direcciones relativas | You can use relative paths
##	Ej. (./Documentos)
##
##	o absolutas | or absolutes
##	Ej. ($HOME/Documentos o /home/<usuario>/Documentos)
##
##	empacar.sh es la version en español | packup.sh is the english version
##
##	Edita solo las lineas que no contengan un # | Only edit lines without the #
EOF
fi
path=$(sed s/#.*//g ./pack-list | sed "s|\$HOME|$HOME|g" | sed "s|\$USER|$USER|g")
printf "Se va a empaquetar:\n$path\n¿Esta bien?\n(S/N)\n"
read verif
if [ $verif = N ]
then
	echo "Operacion cancelada"
	exit
fi
if [ $verif = S ]
then
	echo "Empacando, no cierres esta ventana ni apagues el equipo"
	tar --create --keep-newer-files -p -P --add-file $path -f Paquete.tar.xz && echo "¡Listo!"
else
	echo "Respuesta invalida."
fi
