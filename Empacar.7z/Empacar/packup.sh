#!/bin/bash
check=$(ls | grep -c pack-list)
if [ $check = 0 ]
then
cat >> pack-list << EOF
$HOME/Documentos
/home/$USER/Imágenes
##	Podes poner direcciones relativas | You can use relative paths
##	Ej. (./Documentos)
##
##	o absolutas | or absolutes
##	Ej. ($HOME/Documentos o /home/<usuario>/Documentos)
##
##	empacar.sh es la version en español | packup.sh is the english version
##
##	Edita solo las lineas que no contengan un # | Only edit lines without the #
EOF
fi
path=$(sed s/#.*//g ./pack-list | sed "s|\$HOME|$HOME|g" | sed "s|\$USER|$USER|g")
printf "the following will be packaged:\n$path\nis it ok?\n(Y/N)\n"
read verif
if [ $verif = N ]
then
	echo "Canceled operation."
	exit
fi
if [ $verif = Y ]
then
	echo "Packaging, don't close this window or shutdown the pc"
	tar --create --keep-newer-files --add-file $path -f Pack.tar.xz && echo "Done!"
else
	echo "Invalid response."
fi
